#pragma once
#include "figure.hpp"
#include <stdexcept>
#include <array>

class triangle : public figure {
public:
    triangle(double a, double b, double c);

    double perimeter() const override;
    std::string to_string() const override;

private:
    const std::array<double, 3> sides_;
};