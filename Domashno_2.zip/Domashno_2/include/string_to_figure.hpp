#pragma once
#include "figure.hpp"
#include <memory>
#include <string>

class string_to_figure {
public:
    
    std::unique_ptr<figure> create_from(const std::string& representation) const;
};