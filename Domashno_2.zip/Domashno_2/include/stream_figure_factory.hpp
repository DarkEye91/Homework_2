#pragma once
#include "figure_factory.hpp"
#include "string_to_figure.hpp"
#include <istream>
#include <memory>
#include <string>

class stream_figure_factory : public figure_factory {
public:
    stream_figure_factory(std::istream& in);

    std::unique_ptr<figure> create() override;

private:
    std::istream& in_;
    string_to_figure parser_;
};