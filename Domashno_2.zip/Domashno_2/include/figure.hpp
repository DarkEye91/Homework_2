#pragma once
#include "string_convertible.hpp"

class figure : public string_convertible {
public:
    virtual double perimeter() const = 0;
    virtual ~figure() = default;
};