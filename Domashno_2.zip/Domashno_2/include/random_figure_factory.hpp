#pragma once
#include "figure_factory.hpp"
#include <random>
#include <memory>

class random_figure_factory : public figure_factory {
public:
    random_figure_factory();

    std::unique_ptr<figure> create() override;

private:
    std::mt19937 rng_;
    std::uniform_int_distribution<int> figure_dist_;
    
    std::uniform_real_distribution<double> triangle_side_dist_;
    std::uniform_real_distribution<double> circle_radius_dist_;
};