#pragma once
#include "figure.hpp"
#include <stdexcept>

class circle : public figure {
public:
    explicit circle(double radius);

    double perimeter() const override;
    std::string to_string() const override;

private:
    const double radius_;
};