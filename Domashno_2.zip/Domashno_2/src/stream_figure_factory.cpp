#include "stream_figure_factory.hpp"
#include <stdexcept>
#include <string>

stream_figure_factory::stream_figure_factory(std::istream& in)
    : in_(in)
{}

std::unique_ptr<figure> stream_figure_factory::create() {
    std::string line;
    if (!std::getline(in_, line)) {
        throw std::runtime_error("No more figures to read from stream.");
    }
    return parser_.create_from(line);
}