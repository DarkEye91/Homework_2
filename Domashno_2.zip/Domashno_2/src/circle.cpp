#include "circle.hpp"
#include <stdexcept>
#include <cmath>
#include <sstream>

circle::circle(double radius)
    : radius_(radius)
{
    if (radius <= 0.0) {
        throw std::invalid_argument("Circle radius must be positive.");
    }
    double perimeter = 2 * M_PI * radius;
    if (!std::isfinite(perimeter)) {
        throw std::overflow_error("Circle perimeter overflow.");
    }
}

double circle::perimeter() const {
    return 2 * M_PI * radius_;
}

std::string circle::to_string() const {
    std::ostringstream oss;
    oss << "circle " << radius_;
    return oss.str();
}