#include "string_to_figure.hpp"
#include "triangle.hpp"
#include "circle.hpp"
#include <sstream>
#include <stdexcept>
#include <cctype>

std::unique_ptr<figure> string_to_figure::create_from(const std::string& representation) const {
    std::istringstream iss(representation);
    std::string type;
    iss >> type;
    if (type.empty()) {
        throw std::invalid_argument("Input string is empty or does not start with a figure type.");
    }
    if (type == "triangle") {
        double a, b, c;
        if (!(iss >> a >> b >> c)) {
            throw std::invalid_argument("Invalid or missing triangle parameters.");
        }
        // Проверка за допълнителни символи
        std::string dummy;
        if (iss >> dummy) {
            throw std::invalid_argument("Too many parameters for triangle.");
        }
        return std::make_unique<triangle>(a, b, c);
    } else if (type == "circle") {
        double r;
        if (!(iss >> r)) {
            throw std::invalid_argument("Invalid or missing circle parameter.");
        }
        std::string dummy;
        if (iss >> dummy) {
            throw std::invalid_argument("Too many parameters for circle.");
        }
        return std::make_unique<circle>(r);
    } else {
        throw std::invalid_argument("Unknown figure type: " + type);
    }
}