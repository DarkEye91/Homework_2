#include <iostream>
#include <memory>
#include <string>
#include "figure_factory.hpp"
#include "random_figure_factory.hpp"
#include "stream_figure_factory.hpp"

int main() {
    std::cout << "How would you like to create the figures?\n";
    std::cout << "1. Random\n";
    std::cout << "2. From STDIN\n";
    std::cout << "Enter 1 or 2: ";
    int choice;
    while (!(std::cin >> choice) || (choice != 1 && choice != 2)) {
        std::cout << "Please enter 1 or 2: ";
        std::cin.clear();
        std::cin.ignore(10000, '\n');
    }
    
    std::cin.ignore(10000, '\n');

    std::unique_ptr<figure_factory> factory;
    if (choice == 1) {
        factory = std::make_unique<random_figure_factory>();
    } else {
        factory = std::make_unique<stream_figure_factory>(std::cin);
    }

    std::cout << "How many figures would you like to create? ";
    int n;
    while (!(std::cin >> n) || n <= 0) {
        std::cout << "Please enter a positive integer: ";
        std::cin.clear();
        std::cin.ignore(10000, '\n');
    }
    std::cin.ignore(10000, '\n');

    int total_perimeter = 0;
    for (int i = 0; i < n; ++i) {
        try {
            std::unique_ptr<figure> fig = factory->create();
            std::cout << fig->to_string() << std::endl;
            double p = fig->perimeter();
            
            total_perimeter += static_cast<int>(p);
        } catch (const std::exception& ex) {
            std::cerr << "Error creating figure: " << ex.what() << std::endl;
            
            if (choice == 1) --i;
        }
    }

    std::cout << "Sum of perimeters: " << total_perimeter << std::endl;
    
    return 0;
}