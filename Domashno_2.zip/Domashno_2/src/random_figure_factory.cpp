#include "random_figure_factory.hpp"
#include "triangle.hpp"
#include "circle.hpp"
#include <chrono>

random_figure_factory::random_figure_factory()
    : rng_(static_cast<unsigned>(std::chrono::system_clock::now().time_since_epoch().count())),
      figure_dist_(0, 1), // 0 = triangle, 1 = circle
      triangle_side_dist_(1.0, 100.0), 
      circle_radius_dist_(1.0, 50.0)  
{}

std::unique_ptr<figure> random_figure_factory::create() {
    int type = figure_dist_(rng_);
    if (type == 0) { 
        double a, b, c;
        
        while (true) {
            a = triangle_side_dist_(rng_);
            b = triangle_side_dist_(rng_);
            c = triangle_side_dist_(rng_);
            try {
                return std::make_unique<triangle>(a, b, c);
            } catch (...) {
                
            }
        }
    } else { 
        double r = circle_radius_dist_(rng_);
        return std::make_unique<circle>(r);
    }
}