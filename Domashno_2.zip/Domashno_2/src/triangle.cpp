#include "triangle.hpp"
#include <stdexcept>
#include <limits>
#include <cmath>
#include <sstream>

triangle::triangle(double a, double b, double c)
    : sides_{a, b, c}
{
    if (a <= 0.0 || b <= 0.0 || c <= 0.0) {
        throw std::invalid_argument("Triangle sides must be positive.");
    }
    if (a + b <= c || a + c <= b || b + c <= a) {
        throw std::invalid_argument("Triangle sides do not satisfy triangle inequality.");
    }
    double sum = a + b + c;
    if (!std::isfinite(sum)) {
        throw std::overflow_error("Triangle perimeter overflow.");
    }
}

double triangle::perimeter() const {
    return sides_[0] + sides_[1] + sides_[2];
}

std::string triangle::to_string() const {
    std::ostringstream oss;
    oss << "triangle " << sides_[0] << " " << sides_[1] << " " << sides_[2];
    return oss.str();
}