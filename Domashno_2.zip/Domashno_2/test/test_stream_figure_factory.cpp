#include "catch.hpp"
#include "stream_figure_factory.hpp"
#include <sstream>

TEST_CASE("Stream figure factory reads multiple figures", "[stream_figure_factory]") {
    std::istringstream input("triangle 3 4 5\ncircle 7\ntriangle 5 7 10\n");
    stream_figure_factory factory(input);

    auto fig1 = factory.create();
    REQUIRE(fig1->to_string() == "triangle 3 4 5");
    REQUIRE(fig1->perimeter() == Approx(12.0));

    auto fig2 = factory.create();
    REQUIRE(fig2->to_string() == "circle 7");
    REQUIRE(fig2->perimeter() == Approx(2 * 3.14159265358979323846 * 7));

    auto fig3 = factory.create();
    REQUIRE(fig3->to_string() == "triangle 5 7 10");
    REQUIRE(fig3->perimeter() == Approx(22.0));

    // Проверка, че при изчерпване на входа се хвърля изключение
    REQUIRE_THROWS_AS(factory.create(), std::runtime_error);
}