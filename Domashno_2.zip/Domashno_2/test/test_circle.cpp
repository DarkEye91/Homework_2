#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "circle.hpp"
#include <cmath>
#include <limits>

TEST_CASE("Circle: Correct perimeter", "[circle]") {
    circle c(2.0);
    REQUIRE(c.perimeter() == Approx(2 * M_PI * 2.0));
}

TEST_CASE("Circle: String representation", "[circle]") {
    circle c(2.2);
    REQUIRE(c.to_string() == "circle 2.2");
}

TEST_CASE("Circle: Throws for zero or negative radius", "[circle]") {
    REQUIRE_THROWS_AS(circle(0), std::invalid_argument);
    REQUIRE_THROWS_AS(circle(-1), std::invalid_argument);
}

TEST_CASE("Circle: Throws for overflow", "[circle]") {
    double huge = std::numeric_limits<double>::max();
    REQUIRE_THROWS_AS(circle(huge), std::overflow_error);
}