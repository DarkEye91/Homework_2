#include "catch.hpp"
#include "string_to_figure.hpp"
#include "triangle.hpp"
#include "circle.hpp"

TEST_CASE("String factory creates correct triangle", "[string_to_figure]") {
    string_to_figure factory;
    auto fig = factory.create_from("triangle 3 4 5");
    REQUIRE(fig->to_string() == "triangle 3 4 5");
    REQUIRE(fig->perimeter() == Approx(12.0));
}

TEST_CASE("String factory creates correct circle", "[string_to_figure]") {
    string_to_figure factory;
    auto fig = factory.create_from("circle 2.2");
    REQUIRE(fig->to_string() == "circle 2.2");
    REQUIRE(fig->perimeter() == Approx(2 * 3.14159265358979323846 * 2.2));
}

TEST_CASE("String factory throws on empty string", "[string_to_figure]") {
    string_to_figure factory;
    REQUIRE_THROWS_AS(factory.create_from(""), std::invalid_argument);
}

TEST_CASE("String factory throws on missing triangle parameters", "[string_to_figure]") {
    string_to_figure factory;
    REQUIRE_THROWS_AS(factory.create_from("triangle 10 20"), std::invalid_argument);
}

TEST_CASE("String factory throws on too many triangle parameters", "[string_to_figure]") {
    string_to_figure factory;
    REQUIRE_THROWS_AS(factory.create_from("triangle 10 20 30 40"), std::invalid_argument);
}

TEST_CASE("String factory throws on invalid parameter type", "[string_to_figure]") {
    string_to_figure factory;
    REQUIRE_THROWS_AS(factory.create_from("triangle 10 abc -30"), std::invalid_argument);
    REQUIRE_THROWS_AS(factory.create_from("circle abc"), std::invalid_argument);
}

TEST_CASE("String factory throws on negative parameter", "[string_to_figure]") {
    string_to_figure factory;
    REQUIRE_THROWS_AS(factory.create_from("triangle -10 20 30"), std::invalid_argument);
    REQUIRE_THROWS_AS(factory.create_from("circle -1"), std::invalid_argument);
}

TEST_CASE("String factory throws on unknown figure type", "[string_to_figure]") {
    string_to_figure factory;
    REQUIRE_THROWS_AS(factory.create_from("unknown 10 20 30"), std::invalid_argument);
}