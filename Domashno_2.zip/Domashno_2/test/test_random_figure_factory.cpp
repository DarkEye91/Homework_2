#include "catch.hpp"
#include "random_figure_factory.hpp"
#include "triangle.hpp"
#include "circle.hpp"

TEST_CASE("Random figure factory generates figures in valid ranges", "[random_figure_factory]") {
    const int N = 1000;
    random_figure_factory factory;
    int triangle_count = 0;
    int circle_count = 0;
    for (int i = 0; i < N; ++i) {
        auto fig = factory.create();
        auto str = fig->to_string();
        if (str.find("triangle") == 0) {
            ++triangle_count;
            // Проверка за валидни страни (1 <= side <= 100)
            double a, b, c;
            sscanf(str.c_str(), "triangle %lf %lf %lf", &a, &b, &c);
            REQUIRE(a >= 1.0);
            REQUIRE(a <= 100.0);
            REQUIRE(b >= 1.0);
            REQUIRE(b <= 100.0);
            REQUIRE(c >= 1.0);
            REQUIRE(c <= 100.0);
        } else if (str.find("circle") == 0) {
            ++circle_count;
            double r;
            sscanf(str.c_str(), "circle %lf", &r);
            REQUIRE(r >= 1.0);
            REQUIRE(r <= 50.0);
        } else {
            FAIL("Unknown figure type generated.");
        }
    }
    // Проверка, че има и от двата вида фигури
    REQUIRE(triangle_count > 0);
    REQUIRE(circle_count > 0);
}