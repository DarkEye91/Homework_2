#include "triangle.hpp"
#include "catch.hpp"

TEST_CASE("Triangle perimeter correct", "[triangle]") {
    triangle t(3, 4, 5);
    REQUIRE(t.perimeter() == Approx(12.0));
}

TEST_CASE("Triangle invalid sides throw", "[triangle]") {
    REQUIRE_THROWS_AS(triangle(0, 1, 1), std::invalid_argument);
    REQUIRE_THROWS_AS(triangle(-1, 1, 1), std::invalid_argument);
    REQUIRE_THROWS_AS(triangle(1, 2, 10), std::invalid_argument);
}

TEST_CASE("Triangle overflow perimeter throws", "[triangle]") {
    double huge = std::numeric_limits<double>::max() / 2;
    REQUIRE_THROWS_AS(triangle(huge, huge, huge), std::overflow_error);
}

TEST_CASE("Triangle string representation", "[triangle]") {
    triangle t(3, 4, 5);
    REQUIRE(t.to_string() == "triangle 3 4 5");
}